import pickle
import constants
temp_dir = constants.TEMP_DIR

def PredictH1B(Userinfo, Way='Default'):
    if Way == 'Default':
        filename = 'H1B_LR_MODEL_2020.pickle'
        COLfile = 'H1B_LR_MODEL_2020_COL.pickle'
    elif Way == 'User':
        filename = 'H1B_USER_MODEL.pickle'
        COLfile = 'H1B_USER_MODEL_COL.pickle'

    pickle_in = open(temp_dir + filename,"rb")
    model = pickle.load(pickle_in)

    pickle_in2 = open(temp_dir + COLfile, "rb")
    COLsample = pickle.load(pickle_in2)

    df = Userinfo
    data = pd.get_dummies(df)
    missing_cols = set(COLsample.columns) - set(data.columns)
    # Add a missing column in user info with default value equal to 0
    for c in missing_cols:
        data[c] = 0
    # Ensure the order of column in the user info is in the same order than in train set
    data = data[COLsample.columns]

    # Return predict result and probabilities.
    print(model.predict(data))
    print(model.predict_proba(data))

def PredictPERM(Userinfo, Way='Default'):
    if Way == 'Default':
        filename = 'PERM_RF_MODEL_2020.pickle'
        COLfile = 'PERM_RF_MODEL_2020_COL.pickle'
    elif Way == 'User':
        filename = 'PERM_USER_MODEL.pickle'
        COLfile = 'PERM_USER_MODEL_COL.pickle'

    pickle_in = open(temp_dir + filename,"rb")
    model = pickle.load(pickle_in)

    pickle_in2 = open(temp_dir + COLfile, "rb")
    COLsample = pickle.load(pickle_in2)

    df = Userinfo
    data = pd.get_dummies(df)
    missing_cols = set(COLsample.columns) - set(data.columns)
    # Add a missing column in user info with default value equal to 0
    for c in missing_cols:
        data[c] = 0
    # Ensure the order of column in the user info is in the same order than in train set
    data = data[COLsample.columns]

    # Return predict result and probabilities.
    print(model.predict(data))
    print(model.predict_proba(data))

